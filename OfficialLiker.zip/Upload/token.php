
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="ie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
  <!-- Basic Page Needs -->
  <meta charset="utf-8">
  <title>Access Token - Official Liker</title>
  <link href="css/boot.css" rel="stylesheet">
<link href="http://static.ak.official-liker.net/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>

       <link href='http://fonts.googleapis.com/css?family=Chau+Philomene+One:400,400italic' rel='stylesheet' type='text/css'>  <!-- Mobile Specific Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <!-- Main Style -->
  <link rel="stylesheet" href="css/style.css"> 
  
  <!-- Color Style -->
  <link rel="stylesheet" href="css/skins/colors/red.css" name="colors">
  
  <!-- Layout Style -->
  <link rel="stylesheet" href="css/layout/wide.css" name="layout">
  
  <!--[if lt IE 9]>
      <script src="js/html5.js"></script>
  <![endif]-->

</div>
</head>
<body>

 <div id="wrap" class="boxed">
 <?php include 'includes/menu.php';?> 
<!-- <<< End Header >>> -->
   
   <!-- Start main content -->
 <div class="page-404">
   <div class="container main-content clearfix">
     
     <div class="sixteen columns">
      
      <div class="text">Access Token</div><hr>
      <div class="text"><b><h3>- Step 1 -</h3></b>
<img src="arrow1.png" width="50" height="50"><br>
<a href="is.php" target="_blank" class="btn btn-danger btn-large">First Click Here To Allow Permissions!</a>
<script src="http://admaster.union.ucweb.com/js/union_html5_sdk.js"></script>
<script>
     try{ 
        Umobi.AdView({
            pub:"Isha@cozumeevet",
            format_type:Umobi.AdFormatType.BANNER
        });
     }catch(e){}
</script>
<noscript><?php $tm= uniqid(); ?>
<a href="http://click.union.ucweb.com/?pub=Isha@cozumeevet&tm=<?php echo $tm ?>">
    <img src="http://slot.union.ucweb.com/?pub=Isha@cozumeevet&format_type=img&tm=<?php echo $tm ?>"/>
</a></noscript>

<b><h3>- Step 2 -</h3></b>
<img src="arrow2.png" width="50" height="50"><br>
<form action="is2.php" method="GET">
<input type="submit" value="Then Click Here To Get Access Token!" class="btn btn-success btn-large"></form></div>
      
      <div class="coffee">
	  <input type="hidden" name="IL_IN_TAG" value="2"/>
      </div>
      
     
     </div><!-- End column -->
     
   </div><!-- <<< End Container >>> -->
   </div>
   

   <?php include 'includes/footer.php';?>
<!-- <<< End Footer >>> -->
  
  </div><!-- End wrap -->
    <script src="js/LOL.js"></script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script src="js/jquery.easing.1.3.min.js"></script>
    <script src="js/jquery-ui/jquery.ui.core.js"></script>
    <script src="js/jquery-ui/jquery.ui.widget.js"></script>
    <script src="js/jquery-ui/jquery.ui.accordion.js"></script>
    <script src="js/jquery-cookie.js"></script>
    <script src="js/ddsmoothmenu.js"></script>
     <script src="js/colortip.js"></script>
    <script src="js/tytabs.js"></script> 
    <script src="js/jquery.ui.totop.js"></script>
    <script src="js/carousel.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/custom.js"></script>

</body>
</html>