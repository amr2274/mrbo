<link rel="stylesheet" type="text/css" href="https://www.easyliker.com/autopost/moduls/css.css" media="all,handheld"/>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "https://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Multy Poster | Official Liker</title>
</head>
<body><center>
<div class="shoutmenu">
<table cellspacing="0" cellpadding="0" class="lr">
<tr>
<td valign="top">
<a href="http://www.wpcoderx.com">
<img src="../logo-new.png" width="170" height="40" class="img" alt="WpCoderX"
</a>
</td>
<td valign="top" class="r">
<span class="fcw mfsm">
</tr>
</table>
</div>