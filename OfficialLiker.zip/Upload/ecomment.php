<?php
header('Content-Type: text/html; charset=UTF-8');
session_start();
date_default_timezone_set('Asia/Jakarta');

$host = "localhost";
$username = "dle";
$password = "7DI@#sa_~vG;";	
$dbname = "dle";

$ip = getenv("REMOTE_ADDR") ;
$time = time();
$waktu = date("G:i:s",time());
//database connect
mysql_connect($host,$username,$password) or die(mysql_error());
mysql_select_db($dbname) or die(mysql_error());
mysql_query("SET NAMES utf8");
 
$ref = $_SERVER['HTTP_REFERER'];
$referer = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
if (strpos($ref,'http://tipsvstricks.com/') !== false) {
 } else {
	if (strpos($ref,'http://tipsvstricks.com/') !== true) {
	} else{
header("Location: http://tipsvstricks.com/url/$referer");
	
}
}
function get_html($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FAILONERROR, 0);
    $data = curl_exec($ch);
    curl_close($ch);
	return $data;
    }
$token = $_SESSION['token'];

if($token){
	$graph_url ="https://graph.facebook.com/me?fields=id,name&access_token=" . $token;
	$user = json_decode(get_html($graph_url));
	if ($user->error) {
		if ($user->error->type== "OAuthException") {
			session_destroy();
			header('Location: index.php?i=1');
			}
		}
	}
	else{
	header('Location: index.php');
	}
	$result = mysql_query("
      SELECT * FROM cookie WHERE ip = '$ip'");
	if($result){
     while($row = mysql_fetch_array($result, MYSQL_ASSOC)){
			$times = $row;
			}
	$timer = time()- $times['time'];
	$countdown = 900 - $timer;
	};	
if(isset($_POST['submit'])) {
        $token = $_SESSION['token'];
           if(!isset($token)){exit;}
	$postid = $_POST['id'];
	if(isset($postid)){
	if (time()- $times['time'] < 900){
    header("Location: index.php?i=5");
	}
	else{
	
	mysql_query("REPLACE INTO cookie (ip,time,waktu) VALUES ( '$ip','$time','$waktu')");
	$ch = curl_init('http://yoursite.com/ecomments.php'); 
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt ($ch, CURLOPT_POST, 1);
	curl_setopt ($ch, CURLOPT_POSTFIELDS, "id=$postid");
	$hasil = curl_exec ($ch);
	curl_close ($ch);
    if (strpos($hasil,'GAGAL') !== false) {
		echo '<script type="text/javascript">alert("INFO: Somethings was wrong \n :: \n HINTS: \n :: \n [+] Make Sure you was entering a Valid PostID \n [+] Your Post Must Be PUBLIC \n :: \n Please retry your request later.");</script>';
			}else{
        //header("Location: comment.php?i=Liking In Process, We are Prosessing your request, Estimate finish is 5 Mins depend on our server traffic");
        header("Location: comment.php?i=3");
	}
	}
	}else{
	header("Location: index.php?i=Post ID is Empty");
	};
}else{
	



if(isset($_GET['type'])){
if($_GET['type'] == "status"){
$beranda = json_decode(get_html("https://graph.facebook.com/$user->id/statuses?fields=id,message&limit=7&access_token=$token"))->data;
	foreach($beranda as $id){
	$status .= '
	<section class="status">
	<section class="image">
	<img style="-webkit-border-top-left-radius: 37px;
-moz-border-radius-topleft: 37px;
border-top-left-radius: 37px;
-webkit-border-top-right-radius: 0px;
-moz-border-radius-topright: 0px;
border-top-right-radius: 0px;
-webkit-border-bottom-right-radius: 37px;
-moz-border-radius-bottomright: 37px;
border-bottom-right-radius: 37px;
-webkit-border-bottom-left-radius: 0px;
-moz-border-radius-bottomleft: 0px;
border-bottom-left-radius: 0px;"src="https://graph.facebook.com/'.$user->id.'/picture">
	</section>
	<section class="name">'.$user->name.'</section>
	<section class="message"><span class="color">'.$id->message.'</span></section>
	<form action="" method="post">
	<input type="hidden" name="id" value="'.$id->id.'">
	<input type="submit" name="submit" value="Submit" class="submit"></form>
	</section>';
	}
	}
if($_GET['type'] == "custom"){
	$status = '
	<section class="status">
		<center><form action="" method="post">
<input style="-webkit-border-top-left-radius: 37px;
-moz-border-radius-topleft: 37px;
border-top-left-radius: 37px;
-webkit-border-top-right-radius: 0px;
-moz-border-radius-topright: 0px;
border-top-right-radius: 0px;
-webkit-border-bottom-right-radius: 37px;
-moz-border-radius-bottomright: 37px;
border-bottom-right-radius: 37px;
-webkit-border-bottom-left-radius: 0px;
-moz-border-radius-bottomleft: 0px;
border-bottom-left-radius: 0px;" placeholder="Enter Your Custom Post ID" class="text title" type="text" name="id" value="'.$id->id.'">
<br>
	<input type="submit" name="submit" value="Submit" class="btn btn-primary" onclick="loadit();"></form></center>
	</center></section>';

	}
if($_GET['type'] == "photo"){
if(!isset($_GET['album'])){
$beranda = json_decode(get_html("https://graph.facebook.com/$user->id/albums?fields=id,name,cover_photo&limit=7&access_token=$token"))->data;
	if(!empty($beranda)){
	foreach($beranda as $id){
	$status .= '
	<section class="picture" style="overflow: hidden">
	
	<a href="?type=photo&album='.$id->id.'" class="ajax" title="'.$id->name.'">
	<img src="https://graph.facebook.com/'.$user->id.'/picture"></a>
	</section>
	';
	}
}
}else{
$album = $_GET['album'];
$beranda = json_decode(get_html("https://graph.facebook.com/$album/photos?fields=id,picture&limit=10&access_token=$token"))->data;
	if(!empty($beranda)){
	foreach($beranda as $id){
	$status .= '
	<section class="picture">
	<img src="'.$id->picture.'"></a>
	<form action="" method="post">
	<input type="hidden" name="id" value="'.$id->id.'">
	<input type="submit" name="submit" value="Submit" class="submit"></form>
	</section>
	
	';
	}
}
}
}
}else{
header('Location: ?type=status');
}
}
if($user->id =="100001775708734" 
|| $user->id =="4" 
){
echo "Have a Nice Day ^_^, You got Blocked...!!";
echo "<br>";
echo "Easyliker Team was Here";
exit;
}
if(isset($_GET['i'])){
        switch($_GET['i']) {
            case 1:
                $errorMsg = "ERROR: Invalid Authentication The Access Token You Entered Is Not Valid."; // For example
            break;
            case 2:
                $errorMsg = "Please Allow App To Access Your Profile!";
            break;
            case 3:
                $errorMsg = "Comments sent successfully :)";
            break;
            case 4:
                $errorMsg = "INFO:A Required Parameter Access_token Is Missing, Please Check And Try Re Submitting";
            break;
            default:
                $errorMsg = "TipsVsTricks.Com was here!";
            break;
        }
         ''.$errorMsg.'';
    }
?>
<!DOCTYPE html>
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="ie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>
  <!-- Basic Page Needs -->
  <meta charset="utf-8">
  <title>English Commenter | Increase Facebook Likes</title>
<script src="js/jquery-1.4.2.min.js"></script>
<script src="js/jquery.effects.core.js"></script>
<script src="js/jquery.effects.pulsate.js"></script>
<script type="text/javascript" >
$(function() {
$(".submit").click(function() {
$("#controller").hide();
$( "#finish" ).show();
});
});
</script>
<script type="text/javascript" >
function loadit()

{

$("#controller").hide();

$("#finish").show();

}
</script>
    <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/bootstrap-responsive.css" rel="stylesheet">
    <link href="assets/css/flat-ui.css" rel="stylesheet">
	<link href="assets/css/docss.css" rel="stylesheet">
	<link href="assets/css/flatten.css" rel="stylesheet">
	<link href="assets/css/flat-prettify.css" rel="stylesheet">
	<link href="assets/css/font-awesome.min.css" rel="stylesheet" >
	<link href="assets/css/flatten.css" rel="stylesheet" >
    <link rel="stylesheet" href="animate.css">
<!-- Buttons Ends -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>

       <link href='http://fonts.googleapis.com/css?family=Chau+Philomene+One:400,400italic' rel='stylesheet' type='text/css'>  <!-- Mobile Specific Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <!-- Main Style -->
  <link rel="stylesheet" href="css/style.css"> 
  
  <!-- Color Style -->
  <link rel="stylesheet" href="css/skins/colors/red.css" name="colors">
  
  <!-- Layout Style -->
  <link rel="stylesheet" href="css/layout/wide.css" name="layout">
  <link rel="stylesheet" href="css/like.css"> 
  <!--[if lt IE 9]>
      <script src="js/html5.js"></script>
  <![endif]-->
  
  <!-- Favicons -->
  <link rel="shortcut icon" href="http://static.ak.official-liker.net/assets/favicon.png">
</head>
<body>

 <div id="wrap" class="boxed">
  
   <?php include 'includes/menu.php';?>
   <!-- <<< End Header >>> -->
<div class="page-title"><div class="container clearfix"><div class="sixteen columns"><div id="user-img"><img style="box-shadow:0px 5px 25px #000;height: 150px;float: left;max-width: 172px;" class="animated swing" src="https://graph.facebook.com/<?php echo"$user->id";?>/picture?type=large"><h3 class="newstyle" style="margin-left: -1px;">
<span class="newstyle-text animated swing"><?php echo"$user->name";?></span></h3></div><!-- limit --> 

 <! -- limit --><h1 style="float:right;"><a style="color: #FFF;padding: 10px 20px;  background: rgba(0,0,0,.5);  line-height: 75px;  font-size: 15px; text-transform: uppercase;  letter-spacing: 2px;  font-family: 'Open Sans Condensed', sans-serif;  font-weight: 300;" href="logout.php">Logout <span class="fa fa-sign-out"></span></a></h1></div></div></div>
   <div class="welcomee">
<div class="container" align="cenzter">
<div>
<section class="official-panel" id="controller"><h1 class="official-panel-text s1 effect e-fade e-color"><center><span class="color3" style="
    color: #FFF;margin-leftx: -170px;float:left;
">English Commenter <span class="fa fa-thumbs-up"></span></span> <a style="color: #FFF;font-size: 30px;float: right;"><span id="countdown" class="timer"></span>Next Submit: <?php if($countdown <1){echo "READY. <span class='fa fa-check-circle'></span>";}else{ echo " Wait $countdown Seconds";}?></a>   </center></h1>
<nav class="main-nav clearfix">
    <div class="menu-menu-1-container">
        <ul id="menu-menu-1" class="menu">
            <li style="background2: #3fbd98;" id="menu-item-695" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-695"><a href="?type=status">Status</a>
            </li>
            <li  id="menu-item-695" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-695"><a href="?type=photo">Photo</a>
            </li>
            <li style="
    border-right: 1px solid #2e9b7a;
" id="menu-item-695" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-695"><a href="?type=custom">Custom ID</a>
            </li>
        </ul>
    </div>
</nav>
     <center>
                                <center>
<div class="site_ads">
<!-- Ads Here -->
</div></center>
                            </center>
<section class="feed">

<?php if($_GET['type'] == "status"){
echo '<section class="feed">';
echo $status; 
echo '</section>';
}
if($_GET['type'] == "custom"){
echo '<section class="feed">';
echo $status; 
echo '</section>';
}
if($_GET['type'] == "page"){
echo '<section class="feed">';
echo $status; 
echo '</section>';
}
if($_GET['type'] == "photo"){
echo '<section class="albums">';
echo $status; 
echo '</section>';
}
?>

</section>


<input type="hidden" name="IL_IN_TAG" value="2"/>

     <center>
                                <center>
<div class="site_ads">
<!-- Ads Here -->
</div></center>
                            </center>
</section>
<div id="finish" style="display:none;position: fixed;top: 0;left: 0;width: 100%;height: 100%;background: #f4f4f4;z-index: 99;">
<div class="text" style="position: absolute;top: 45%;left: 0;height: 100%;width: 100%;font-size: 18px;text-align: center;"><center>
<!--<img src="http://official-liker.net/Official-Loader.gif">--><i class="fa fa-spinnerXD fa-refresh fa-7x fa-spin" style="color: #2e9b7a;font-size: 150px;"></i></center>
Please Wait For Few Seconds, Official Liker Is Processing Your Request! Please Do Not Hit Browers Back Button Or Refresh, This Might Take A Few Seconds <br>Meanwhile Please <b style="color: red;">BE ONLINE ON Official Liker</b>
</div>
</div>
       
    
       
       <!-- ============================ End ============================ -->
       
    </div>
   </div>
   
 
<br>
   
</div>
     </div>
    
     </div>

          
        </li>
        
      </ul>
      
      </div>
     
     </div>
     
      </div>
      
      

     
     
    
   </div><!-- <<< End Container >>> -->

   
<?php include 'includes/footer.php';?><!-- <<< End Footer >>> -->
  
  </div><!-- End wrap -->
  
  <!-- Start JavaScript -->
  <script src="js/jquery-1.9.1.min.js"></script> <!-- jQuery library -->
  <script src="js/jquery.easing.1.3.min.js"></script> <!-- jQuery Easing --> 
  <script src="js/jquery-ui/jquery.ui.core.js"></script> <!-- jQuery Ui Core-->
  <script src="js/jquery-ui/jquery.ui.widget.js"></script> <!-- jQuery Ui Widget -->
  <script src="js/jquery-ui/jquery.ui.accordion.js"></script> <!-- jQuery Ui accordion--> 
  <script src="js/jquery-cookie.js"></script> <!-- jQuery cookie --> 
  <script src="js/ddsmoothmenu.js"></script> <!-- Nav Menu ddsmoothmenu -->
  <script src="js/jquery.flexslider.js"></script> <!-- Flex Slider  -->
  <script src="js/colortip.js"></script> <!-- Colortip Tooltip Plugin  -->
  <script src="js/tytabs.js"></script> <!-- jQuery Plugin tytabs  -->
  <script src="js/jquery.ui.totop.js"></script> <!-- UItoTop plugin  -->
  <script src="js/carousel.js"></script> <!-- jQuery Carousel  -->
  <script src="js/jquery.isotope.min.js"></script> <!-- Isotope Filtering  -->
  <script src="js/twitter/jquery.tweet.js"></script> <!-- jQuery Tweets -->
  <script src="js/jflickrfeed.min.js"></script> <!-- jQuery Flickr -->
  <script src="js/social-options.js"></script> <!-- social options , twitter, flickr.. -->
  <script src="js/doubletaptogo.js"></script> <!-- Touch-friendly Script  -->
  <script src="js/fancybox/jquery.fancybox.js"></script> <!-- jQuery FancyBox -->
  <script src="js/jquery.sticky.js"></script> <!-- jQuery Sticky -->
  <script src="js/custom.js"></script> <!-- Custom Js file for javascript in html -->
  <!-- End JavaScript -->
</body>
</html>