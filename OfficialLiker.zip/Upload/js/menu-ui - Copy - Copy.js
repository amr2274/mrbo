var quotes=new Array()
quotes[0]='<div id="bodyclass"><a href="//wpcoderx.com" target="_blank"><img class="bodyclass" src="http://i.imgur.com/pWkb6lB.png"></a></div>'
var whichquote=Math.floor(Math.random()*(quotes.length))
document.write(quotes[whichquote])