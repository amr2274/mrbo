$(document).ready(function()
{
var aa=$("#credit").val();
if (aa = null) {
    window.location.href = "http://www.wpcoderx.com/";
};
 $("#credit").attr("href","
http://www.wpcoderx.com/");

});