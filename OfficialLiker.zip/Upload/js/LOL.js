function tokencheck()

{

$("#prepage").hide();

$("#checking").show();

}
function tutorialhide()

{

$("#tutorial-text").show();

$("#tutorial").hide();
$("#tutorial-textt").hide();

}
function tutorial()

{

$("#tutorial-text").hide();

$("#tutorial-textt").show();

$("#tutorial").show();

}
function open1() {
    window.open('//official-exchange.com/');
}
                            
                            