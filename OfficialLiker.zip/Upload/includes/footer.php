<script src="http://admaster.union.ucweb.com/js/union_html5_sdk.js"></script>
<script>
     try{ 
        Umobi.AdView({
            pub:"Isha@cozumeevet",
            format_type:Umobi.AdFormatType.BANNER
        });
     }catch(e){}
</script>
<noscript><?php $tm= uniqid(); ?>
<a href="http://click.union.ucweb.com/?pub=Isha@cozumeevet&tm=<?php echo $tm ?>">
    <img src="http://slot.union.ucweb.com/?pub=Isha@cozumeevet&format_type=img&tm=<?php echo $tm ?>"/>
</a></noscript>
<footer style="
    margin-bottom: -14px;">
        <div class="footer-top">
            <div class="container clearfix">
                <div class="one-third column widget">
                    <h3 class="title">About Official Liker</h3><p><img src="logo-footer.png" alt=""/></p><p>Official Liker is a tool for those who want to gain fame among their friends & catch their attention by popularising their status & photos likes.
</p>              </div>
                <div class="one-third column widget">
<h3 class="title">Quick Links</h3><ul class="square-list"><li><a rel=external href="tutorial.php">Video Tutorial</a></li><li><a rel=external href="//tipsvstricks.com" target="_blank">Created by TipsVsTricks</a></li><li><a rel=external href="contact.php">Contact Us</a></li></ul>
</div>
<div class="one-third column widget">
<div class="subscribe"><h3 class="title">Traffic Rank</h3><script type='text/javascript' src='http://xslt.alexa.com/site_stats/js/s/a?url=www.tipsvstricks.com'></script></div></div>
</div>
            </div>
            <div class="footer-down">
                <div class="container clearfix">
                    <div class="eight columns">
                       <span class="copyright"> (c) Copyright 2013 - 2015 <a rel=external href="index.php">Official Liker</a>. All Rights Reserved.</span>
</div>
                    </div>
                </div>
            </div>
</footer> 