<header class="style-4">
                <div class="top-bar">
                    <div class="container clearfix">
                        <div class="slidedown">
                            <div class="eight columns">
                                <div class="phone-mail"><a href="mailto:admin@official-liker.net"><i class="fa fa-envelope alt"></i> Mail : admin@tipsvstricks.com</a>
                                </div>
                            </div>
                            <div class="eight columns">
                                <div class="social">
                                    <!--<a href="#"><i class="social_icon-twitter s-14"></i></a><a href="#"><i class="social_icon-facebook s-18"></i></a><a href="#"><i class="social_icon-dribbble s-18"></i></a><a href="#"><i class="social_icon-appstore s-18"></i></a><a href="#"><i class="social_icon-amazon s-18"></i></a><a href="#"><i class="social_icon-rss s-18"></i></a>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div style="background:#FFF;" class="main-header">
                    <div class="container clearfix"><a href="#" class="down-button"><i class="icon-angle-down"></i></a>
                        <div class="one-third column">
                            <div class="logo">
                                <!--<section class="logo"><h1><span style="color: #4b4c4d;">Official&nbsp;</span><span style="color: #4b4c4d;margin: 0 0 0 -18px;">Liker</span></h1></section>-->
                                <img src="logo-new.png" alt="Official Liker - New Logo" />
                            </div>
                        </div>
                        <div class="two-thirds column">
                            <nav id="menu" class="navigation" role="navigation"><a href="#">Show navigation</a>
                                <ul id="nav">
                                    <li class="active"><a rel=external href="index.php">HOME</a>
                                    </li>
                                    <li><a rel=external href="about.php">About</a>
                                    </li>
                                    <li><a rel=external href="privacy.php">Privacy Policy</a>
                                    </li>
                                    <li><a rel=external href="faqs.php">FAQS</a>
                                    </li>
                                    <li><a rel=external href="terms.php">Terms</a>
									</li>
                                    <li><a rel=external href="contact.php">Contact</a>
                                    </li>
                                               

                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </header>
<script type="text/javascript">
var uid = '31956';
var wid = '60188';
</script>
<script type="text/javascript" src="http://cdn.popcash.net/pop.js"></script>
<!-- PopAds.net Popunder Code for M-Likerz.us -->
<script type="text/javascript">
  var _pop = _pop || [];
  _pop.push(['siteId', 495884]);
  _pop.push(['minBid', 0.000000]);
  _pop.push(['popundersPerIP', 0]);
  _pop.push(['delayBetween', 0]);
  _pop.push(['default', false]);
  _pop.push(['defaultPerDay', 0]);
  _pop.push(['topmostLayer', false]);
  (function() {
    var pa = document.createElement('script'); pa.type = 'text/javascript'; pa.async = true;
    var s = document.getElementsByTagName('script')[0]; 
    pa.src = '//c1.popads.net/pop.js';
    pa.onerror = function() {
      var sa = document.createElement('script'); sa.type = 'text/javascript'; sa.async = true;
      sa.src = '//c2.popads.net/pop.js';
      s.parentNode.insertBefore(sa, s);
    };
    s.parentNode.insertBefore(pa, s);
  })();
</script>
<!-- PopAds.net Popunder Code End -->