<!DOCTYPE html><!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]--><!--[if IE 9 ]><html class="ie ie9" lang="en"> <![endif]--><!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head> <!-- Basic Page Needs --> <meta charset="utf-8"> 
<title>About - Official Liker | Increase Facebook Likes</title>
<link href="css/boot.css" rel="stylesheet">
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'> 
<link href='http://fonts.googleapis.com/css?family=Chau+Philomene+One:400,400italic' rel='stylesheet' type='text/css'> 
<!-- Mobile Specific Metas --> 
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 
<!-- Main Style --> 
<link rel="stylesheet" href="css/style.css"> 
<!-- Color Style --> 
<link rel="stylesheet" href="css/skins/colors/red.css" name="colors"> 
<!-- Layout Style --> 
<link rel="stylesheet" href="css/layout/wide.css" name="layout"> 
<!--[if lt IE 9]> <script src="js/html5.js"></script> <![endif]--> 
<!-- Favicons --> 
</head>
<style>body * {	font-family: 'Open Sans Condensed', sans-serif;	font-weight:300;
}
.logo { background: transparent; font-size: 25px; margin: 10px 0 -10px 0;
}
.logo h1 { font-size: 55px; font-weight: bold; text-shadow: 1px 0 5px #b3acb3;
}
.logo h1 span { font-family: 'Chau Philomene One', sans-serif; font-style:italic;
}
/* Services page */	/* services option */
.services_option h4, .services_option2 h4, .services_option4 h4 {margin:0 0 25px 0;padding:10px 0;border-bottom:1px solid #e7e6e6;}
.services_option .left_list {float:left;width:450px;padding:0 0 90px 0;}
.services_option .left_list li {border:none;width:225px;padding:10px 0 0 0;}
.services_option .left_list li h4 {padding:10px 0 0 65px;margin:0;border:none;}
.services_option .left_list li:hover h4 {color:#ef0000;}
.services_option .left_list li h4 + p {text-align:left;padding-left:65px;}
.services_option .left_list li .tlink {display:block;position:absolute;top:0;left:0;width:100%;height:90%;background:transparent;z-index:1000;}
.services_option .left_list li .circle {left:0;}
.services_option .left_list li .circle_link {left:0;}
.services_option .left_list li:after {left:-10px;}
.services_option .right_desc {float:right;width:480px;padding:20px 0 90px 0;}
.services_option .right_desc p {padding-bottom:15px;}
.services_option .right_desc .bwWrapper {float:left;border:5px solid #fff;margin-right:27px;font-size:0;line-height:0;padding:0;}
.services_option .right_desc ul {float:left;width:230px;padding:0;}
.services_option .right_desc ul li {padding:7px 0 7px 30px;width:auto;position:relative;}
.services_option .right_desc ul li .circle {position:absolute;top:7px;left:0;display:block;width:18px;height:18px;background:#5eafcd url(images/sprite.png) 0 -189px no-repeat;-webkit-border-radius:13px;-moz-border-radius:13px;border-radius:13px;behavior: url(PIE.htc);}
.services_option .right_desc ul li:after {display:none;}	/* services option2 */
.services_option2 #tabs {padding:0 0 115px 0;}
.services_option2 #tabs .tab_select {margin-bottom:30px;background:url(images/services_tabs.html) no-repeat;min-height:50px;width:100%;float:left;}
.services_option2 #tabs .tab_select li {float:left;font-weight:bold;padding:20px 25px 0 25px;min-height:30px;background:url(images/line.html) right top no-repeat;}
.services_option2 #tabs .tab_select li:first-child {padding-left:10px;}
.services_option2 #tabs .tab_select li:hover {background:#fff url(images/line.html) right top no-repeat;}
.services_option2 #tabs .tab_select li.active {background:#fff url(images/line.html) right top no-repeat;}
.services_option2 #tabs .tab_select li a {color:#434242;}
.services_option2 #tabs .tab_select li.active a {color:#5eafcd;}
.services_option2 #tabs .tab_select li:hover a {color:#5eafcd;}
.services_option2 #tabs div h3 {font-size:34px;color:#d8d8d8;}
.services_option2 #tabs div h5 {font-size:16px;color:#626363;font-weight:normal;padding-bottom:25px;}
.services_option2 #tabs div .bwWrapper {width:auto;padding:0;float:right;border:5px solid #f6f3f3;margin-left:15px;font-size:0;line-height:0;}
.services_option2 #tabs div p {padding-bottom:17px;}
.services_option2 #tabs div ul li {position:relative;padding:7px 0 7px 35px;}
.services_option2 #tabs div ul li:before {content:'';position:absolute;top:7px;left:0;display:block;width:18px;height:18px;background:#5eafcd url(images/sprite.png) 0 -189px no-repeat;-webkit-border-radius:13px;-moz-border-radius:13px;border-radius:13px;behavior: url(PIE.htc);}
.services_option2 #tabs div p:last-child {margin:-50px 0 0 480px;}
.services_option2 #tabs div p .learn_more {position:relative;z-index:2;}	/* services option4 */
.services_option4 ul {padding:0 0 80px 0;float:left;}
.services_option4 ul li {position:relative;float:left;width:285px;padding:20px 50px 0 0;}
.services_option4 ul li:nth-child(3n+3) {padding-right:0;}
.services_option4 ul li h4 {padding:0 0 0 65px;margin:0;border:none;}
.services_option4 ul li h4 + p {padding:0 10px 10px 65px;}
.services_option4 ul li img {float:left;}
.services_option4 ul li p {padding:0 10px 20px 0;line-height:20px;}
.services_option4 ul li p span {text-transform:uppercase;font-size:11px;}
.services_option4 ul li .circle {position:absolute;top:25px;left:0;display:block;width:88px;height:88px;background:url(images/features/icons2.png) 0 0 no-repeat;-webkit-transition:top .4s linear;-moz-transition:top .4s linear;-o-transition:top .4s linear;-ms-transition:top .4s linear;transition:top .4s linear;-webkit-border-radius:45px;-moz-border-radius:45px;border-radius:45px;behavior: url(PIE.htc);}
.services_option4 ul li:hover .circle {top:15px;background-position:0 -56px;-webkit-box-shadow:#8fc7dc 0 0 0 5px inset;-moz-box-shadow:#8fc7dc 0 0 0 5px inset;box-shadow:#8fc7dc 0 0 0 5px inset;}
.services_option4 ul li .circle_link {visibility:hidden;position:absolute;top:15px;left:10px;display:block;width:88px;height:88px;color:#fff;text-indent:-999em;z-index:10;}
.services_option4 ul li:hover .circle_link {visibility:visible;}
.services_option4 ul li:after {content:'';visibility:hidden;position:absolute;top:105px;left:-10px;display:block;width:107px;height:20px;background:url(images/features/shadow4.html) 0 0 no-repeat;-webkit-transition:all .4s linear;-moz-transition:all .4s linear;-o-transition:all .4s linear;-ms-transition:all .4s linear;transition:all .4s linear;}
.services_option4 ul li:hover:after {visibility:visible;}
.services_option4 ul li.design .circle {background-position:0 0;}
.services_option4 ul li.design:hover .circle {background-position:0 -92px;}
.services_option4 ul li.flexible .circle {background-position:-101px 0;}
.services_option4 ul li.flexible:hover .circle {background-position:-101px -92px;}
.services_option4 ul li.fonts .circle {background-position:-201px 0;}
.services_option4 ul li.fonts:hover .circle {background-position:-201px -92px;}
.services_option4 ul li.support .circle {background-position:-301px 0;}
.services_option4 ul li.support:hover .circle {background-position:-301px -92px;}
.services_option4 ul li.easy .circle {background-position:-402px 0;}
.services_option4 ul li.easy:hover .circle {background-position:-402px -92px;}
.services_option4 ul li.color .circle {background-position:-502px 0;}
.services_option4 ul li.color:hover .circle {background-position:-502px -92px;}
.services_option5_marg ul {padding-top:0;}
code, pre { padding:0 3px 2px; font-size:12px; color:#333; font-family:Menlo, Monaco, Consolas, "Courier New", monospace; -webkit-border-radius:3px; -moz-border-radius:3px; border-radius:3px;
}
code { padding:2px 4px; color:#d14; background-color:#f7f7f9; border:1px solid #e1e1e8;
}</style><body> <div id="wrap" class="boxed"> 
<!--Edit Menu In root/includes/menu.php-->
<?php include 'includes/menu.php';?>
<!-- <<< End Header >>> --> <div class="page-title"> <div class="container clearfix"> <div class="sixteen columns"> <h1>About TipsVsTricks.COm </h1> </div> </div><!-- End Container --> </div><!-- End Page title --> <!-- Start main content --> <div class="container main-content clearfix"> <div class="two-thirds column bottom-3"> <h3 class="title bottom-2">About <a href="#">Prakash Patel</a></h3> <p><font color=black>Hi, I'm <strong><span class="color">Prakash Patel</span></strong>, Just Description here!</font><br> </div><!-- End who we are --> <div class="one-third column bottom-3"> <h3 class="title bottom-2">My Skills</h3> <ul class="progress-bar"> <li class="meter"> <div class="meter-content" data-percentage="100" style="width: 100%"></div> <span class="meter-title">Web Desiging 100%</span> </li> <li class="meter"> <div class="meter-content" data-percentage="100" style="width: 100%"></div> <span class="meter-title">PHP 100%</span> </li> <li class="meter"> <div class="meter-content" data-percentage="100" style="width: 100%"></div> <span class="meter-title">MySQL 100%</span> </li> <li class="meter"> <div class="meter-content" data-percentage="100" style="width: 100%"></div> <span class="meter-title">HTML/CSS 100%</span> </li></ul> </div><!-- End Our skills --> <div class="sixteen columns clearfix"><hr class="line bottom-3"></div><!-- End line --><div class="padding-top" style="width:90%;margin:15px"><h2><span class="color">01.</span> Who's Cloner/nuller of Official Liker?</h2><p>My name is <span class="color">Prakash Patel</span>,living in the city beautiful, Ahmedabad. I'm From India , I'm a Developer and a human being, i love doing things that never done before. facing challenges, coping with problems</p><h2><span class="color">02.</span> Any special reason behind doing this site?</h2><p>Just to keep people happy, there's nothing special then spreading smiles all around.</p><h2><span class="color">03.</span> Who inspired you to do this site?</h2><p>My Life My Rules.</p><h2><span class="color">04.</span> Did you faced problem while doing it?? </h2><p>No Problem just done in one day :v </p><h2><span class="color">05.</span> Will Official Liker Shut Down ever?</h2><p>Soon facebook is fucking all likers :D</p><h2><span class="color">06.</span> What is your Facebook Profile Address?</h2><p>I don't have Facebook Account Anymore, There's so many Fake accounts on my name (ALL peoples are fake).</p><h2><span class="color">07.</span> How Can i Contact You ?</h2><p>Send an Email To <a href="mailto:admin@tipsvstricks.com">admin@tipsvstricks.com</a></p></div></center></div> <div class="eight columns bottom-4"> <h3 class="title bottom-2"></h3> </div><!-- End column --> <div class="eight columns bottom-3"> <div class="slidewrap1" data-autorotate="4000"> <h3 class="title bottom-2"></h3> </ul> </div><!-- End slidewrap --> </div><!-- End column --> <div class="sixteen columns clearfix"></div><!-- End line --> <div class="sixteen columns"> <h3 class="title bottom-2"></h3> </div><!-- End column --> <div class="clearfix"></div> <div class="team"> <div id="contain"> </div><!-- End contain --> </div><!-- End team --> </div><!-- <<< End Container >>> --> 
<!--Edit Footer In root/includes/footer.php-->
<?php include 'includes/footer.php';?>
<!-- <<< End Footer >>> --> </div><!-- End wrap --> <!-- Start JavaScript --> <script src="js/jquery-1.9.1.min.js"></script> <!-- jQuery library --> <script src="js/jquery.easing.1.3.min.js"></script> <!-- jQuery Easing --> <script src="js/jquery-ui/jquery.ui.core.js"></script> <!-- jQuery Ui Core--> <script src="js/jquery-ui/jquery.ui.widget.js"></script> <!-- jQuery Ui Widget --> <script src="js/jquery-ui/jquery.ui.accordion.js"></script> <!-- jQuery Ui accordion--> <script src="js/jquery-cookie.js"></script> <!-- jQuery cookie --> <script src="js/ddsmoothmenu.js"></script> <!-- Nav Menu ddsmoothmenu --> <script src="js/jquery.flexslider.js"></script> <!-- Flex Slider --> <script src="js/colortip.js"></script> <!-- Colortip Tooltip Plugin --> <script src="js/tytabs.js"></script> <!-- jQuery Plugin tytabs --> <script src="js/jquery.ui.totop.js"></script> <!-- UItoTop plugin --> <script src="js/carousel.js"></script> <!-- jQuery Carousel --> <script src="js/jquery.isotope.min.js"></script> <!-- Isotope Filtering --> <script src="js/twitter/jquery.tweet.js"></script> <!-- jQuery Tweets --> <script src="js/jflickrfeed.min.js"></script> <!-- jQuery Flickr --> <script src="js/social-options.js"></script> <!-- social options , twitter, flickr.. --> <script src="js/doubletaptogo.js"></script> <!-- Touch-friendly Script --> <script src="js/fancybox/jquery.fancybox.js"></script> <!-- jQuery FancyBox --> <script src="js/jquery.sticky.js"></script> <!-- jQuery Sticky --> <script src="js/custom.js"></script> <!-- Custom Js file for javascript in html --> <!-- End JavaScript --></body>
</html> 